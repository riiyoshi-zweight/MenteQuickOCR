import app from '../backend/src/index.js';

export default app;