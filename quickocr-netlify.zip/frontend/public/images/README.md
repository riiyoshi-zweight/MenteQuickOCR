# 画像ファイル配置場所

以下の画像ファイルを配置してください：

- quick-ocr-logo.png - アプリケーションロゴ
- septic-tank-icon.png - 浄化槽アイコン
- industrial-waste-icon.png - 産廃アイコン
- earth-toyama-icon.png - アース富山アイコン
- earth-nagano-icon.png - アース長野アイコン
- jmate-bio-icon.png - Jマテバイオアイコン
- environmental-dev-icon.png - 環境開発アイコン

画像がない場合はプレースホルダーが表示されます。